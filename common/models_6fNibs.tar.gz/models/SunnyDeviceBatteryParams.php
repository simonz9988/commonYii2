<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "sea_sunny_device_battery_params".
 *
 * @property int $id
 * @property int $device_id 设备ID
 * @property string $bat_over_volt 超压电压
 * @property string $bat_charge_limit_volt 充电限制电压
 * @property string $bat_const_charge_volt 均衡充电电压
 * @property string $bat_improve_charge_volt 提升充电电压
 * @property string $bat_float_charge_volt 浮充充电电压
 * @property string $bat_improve_charge_back_volt 充电返回电压
 * @property string $bat_over_discharge_back_volt 过放返回电压
 * @property string $bat_under_volt 欠压警告电压
 * @property string $bat_over_discharge_volt 过放电压
 * @property string $charge_max_temper 充电上限温度
 * @property string $charge_min_temper 充电下限温度
 * @property string $discharge_max_temper 放电下限温度
 * @property string $discharge_min_temper 放电下限温度
 * @property string $light_control_volt 光控电压
 * @property string $is_deleted 是否删除 Y-已删除 N-未删除
 * @property string $create_time 创建时间
 * @property string $modify_time 最后更新时间
 */
class SunnyDeviceBatteryParams extends \common\models\BaseModel
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'sea_sunny_device_battery_params';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['device_id'], 'integer'],
            [['create_time', 'modify_time'], 'safe'],
            [['bat_over_volt', 'bat_charge_limit_volt', 'bat_const_charge_volt', 'bat_improve_charge_volt', 'bat_float_charge_volt', 'bat_improve_charge_back_volt', 'bat_over_discharge_back_volt', 'bat_under_volt', 'bat_over_discharge_volt', 'charge_max_temper', 'charge_min_temper', 'discharge_max_temper', 'discharge_min_temper', 'light_control_volt'], 'string', 'max' => 255],
            [['is_deleted'], 'string', 'max' => 1],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'device_id' => 'Device ID',
            'bat_over_volt' => 'Bat Over Volt',
            'bat_charge_limit_volt' => 'Bat Charge Limit Volt',
            'bat_const_charge_volt' => 'Bat Const Charge Volt',
            'bat_improve_charge_volt' => 'Bat Improve Charge Volt',
            'bat_float_charge_volt' => 'Bat Float Charge Volt',
            'bat_improve_charge_back_volt' => 'Bat Improve Charge Back Volt',
            'bat_over_discharge_back_volt' => 'Bat Over Discharge Back Volt',
            'bat_under_volt' => 'Bat Under Volt',
            'bat_over_discharge_volt' => 'Bat Over Discharge Volt',
            'charge_max_temper' => 'Charge Max Temper',
            'charge_min_temper' => 'Charge Min Temper',
            'discharge_max_temper' => 'Discharge Max Temper',
            'discharge_min_temper' => 'Discharge Min Temper',
            'light_control_volt' => 'Light Control Volt',
            'is_deleted' => 'Is Deleted',
            'create_time' => 'Create Time',
            'modify_time' => 'Modify Time',
        ];
    }

    /**
     * 根据ID返回指定信息
     * @param $id
     * @param $fields
     * @return mixed
     */
    public function getInfoById($id,$fields='*'){

        $params['cond'] = 'id=:id';
        $params['args'] = [':id'=>$id];
        $params['fields'] = $fields ;
        $info = $this->findOneByWhere(self::tableName(),$params,self::getDb());
        return $info ;
    }

    /**
     * 根据ID返回指定信息
     * @param $device_id
     * @param $fields
     * @return mixed
     */
    public function getInfoByDeviceId($device_id,$fields='*'){

        // 查询设备基本信息
        $device_obj = new SunnyDevice();
        $device_info = $device_obj->getInfoById($device_id);

        // 查询电池参数信息
        $params['cond'] = 'device_id=:device_id AND is_deleted=:is_deleted';
        $params['args'] = [':device_id'=>$device_id,':is_deleted'=>'N'];
        $params['fields'] = $fields ;
        $info = $this->findOneByWhere(self::tableName(),$params,self::getDb());
        if($info){
            $info['battery_type'] = $device_info['battery_type'];
        }
        return $info ;
    }


    /**
     *
     * @param $ids
     * @param $post_data
     * @return mixed
     */
    public function savePostData($ids,$post_data){

        $is_save_template = $post_data['is_save_template'] ;
        $template_id = $post_data['template_id'] ;
        $save_template_name = $post_data['save_template_name'] ;

        if($is_save_template){
            unset($post_data['is_save_template']) ;
            unset($post_data['template_id']) ;
            unset($post_data['save_template_name']) ;

            $template_obj = new SunnyDeviceTemplate();
            if(!$template_id){
                // 新增模板
                $template_add_data['name'] =$save_template_name;
                $template_add_data['type'] ='BATTERY';
                $template_add_data['content'] =json_encode($post_data);
                $template_add_data['create_time'] = date('Y-m-d H:i:s');
                $template_add_data['modify_time'] = date('Y-m-d H:i:s');
                $template_id = $this->baseInsert($template_obj::tableName(),$template_add_data);
            }else{
                // 更新模板
                $template_update_data['content'] = json_encode($post_data);
                $template_update_data['modify_time'] = date('Y-m-d H:i:s');
                $this->baseUpdate($template_obj::tableName(),$template_update_data,'id=:id',[":id"=>$template_id]);
            }

            return true ;
        }

        // 批量更新
        $temp_ids = explode('_',$ids);
        $ids_arr = [];
        foreach($temp_ids as $v){
            if($v){
                $ids_arr[] = $v ;
            }
        }

        $device_obj = new  SunnyDevice();
        foreach($ids_arr as $v){

            // 更新蓄电池类型
            $device_update_data['battery_type'] = $post_data['battery_type'];
            $device_update_data['modify_time'] = date('Y-m-d H:i:s');
            $this->baseUpdate($device_obj::tableName(),$device_update_data,'id=:id',[':id'=>$v]);

            $delete_data['is_deleted'] = 'Y';
            $delete_data['modify_time'] = date('Y-m-d H:i:s');
            $this->baseUpdate(self::tableName(),$delete_data,'device_id=:device_id',[':device_id'=>$v]);

            $add_data['device_id'] = $v;
            $add_data['template_id'] = $template_id;
            $add_data['bat_over_volt'] = $post_data['bat_over_volt'];
            $add_data['li_type'] = $post_data['li_type'];
            $add_data['bat_charge_limit_volt'] = $post_data['bat_charge_limit_volt'];
            $add_data['bat_const_charge_volt'] = $post_data['bat_const_charge_volt'];
            $add_data['bat_improve_charge_volt'] = $post_data['bat_improve_charge_volt'];
            $add_data['bat_float_charge_volt'] = $post_data['bat_float_charge_volt'];
            $add_data['bat_improve_charge_back_volt'] = $post_data['bat_improve_charge_back_volt'];
            $add_data['bat_over_discharge_back_volt'] = $post_data['bat_over_discharge_back_volt'];
            $add_data['bat_under_volt'] = $post_data['bat_under_volt'];
            $add_data['bat_over_discharge_volt'] = $post_data['bat_over_discharge_volt'];
            $add_data['charge_max_temper'] = $post_data['charge_max_temper'];
            $add_data['charge_min_temper'] = $post_data['charge_min_temper'];
            $add_data['discharge_max_temper'] = $post_data['discharge_max_temper'];
            $add_data['discharge_min_temper'] = $post_data['discharge_min_temper'];
            $add_data['light_control_volt'] = $post_data['light_control_volt'];
            $add_data['is_deleted'] = 'N';
            $add_data['create_time'] = date('Y-m-d H:i:s');
            $add_data['modify_time'] = date('Y-m-d H:i:s');

            $add_data['bat_discharge_limit_volt'] = $post_data['bat_discharge_limit_volt'];
            $add_data['bat_stop_soc'] = $post_data['bat_stop_soc'];
            $add_data['bat_over_discharge_delay'] = $post_data['bat_over_discharge_delay'];
            $add_data['bat_const_charge_time'] = $post_data['bat_const_charge_time'];
            $add_data['bat_improve_charge_time'] = $post_data['bat_improve_charge_time'];
            $add_data['bat_const_charge_gap_time'] = $post_data['bat_const_charge_gap_time'];
            $add_data['coeff_temper_compen'] = $post_data['coeff_temper_compen'];
            $add_data['heat_bat_start_temper'] = $post_data['heat_bat_start_temper'];
            $add_data['heat_bat_stop_temper'] = $post_data['heat_bat_stop_temper'];
            $add_data['bat_switch_dc_volt'] = $post_data['bat_switch_dc_volt'];
            $add_data['stop_charge_current_set'] = $post_data['stop_charge_current_set'];
            $add_data['dc_load_mode'] = $post_data['dc_load_mode'];
            $add_data['light_control_delay_time'] = $post_data['light_control_delay_time'];

            $this->baseInsert(self::tableName(),$add_data);
        }

        return true ;
    }

    /**
     * @param $device_info
     * @param $post_data
     * @return mixed
     */
    public function saveByProject($device_info,$post_data){

        $battery_type = $post_data['battery_type'];
        $device_update_data['battery_type'] = $battery_type;
        $device_update_data['modify_time'] = date('Y-m-d H:i:s');
        $device_obj = new SunnyDevice();
        $this->baseUpdate($device_obj::tableName(),$device_update_data,'id=:id',[':id'=>$device_info['id']]);

        //$add_data['']
        $info = $this->getInfoByDeviceId($device_info['id']);
        if(!$info){

        }else{
            //$add_data[]
        }
    }
}
