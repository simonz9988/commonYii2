<?php

namespace common\models;

use Yii;
use yii\db\Query;

/**
 * This is the model class for table "sea_operate_log".
 *
 * @property int $id
 * @property string $operate_user_name 操作用户
 * @property string $operate_time 操作时间
 * @property string $class_name 类名
 * @property string $function_name 方法名
 * @property string $action 动作
 * @property int $redundancy_id 冗余id 分别对应 order_id/goods_id
 * @property string $file_path 文件日志路径
 * @property string $old_content 老数据
 * @property string $new_content 新数据
 * @property string $ip
 */
class OperateLog extends \common\models\BaseModel
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'sea_operate_log';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['operate_time', 'class_name', 'function_name', 'action', 'old_content', 'new_content', 'ip'], 'required'],
            [['operate_time'], 'safe'],
            [['redundancy_id'], 'integer'],
            [['old_content', 'new_content'], 'string'],
            [['operate_user_name'], 'string', 'max' => 100],
            [['class_name'], 'string', 'max' => 255],
            [['function_name'], 'string', 'max' => 50],
            [['action', 'ip'], 'string', 'max' => 20],
            [['file_path'], 'string', 'max' => 200],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'operate_user_name' => 'Operate User Name',
            'operate_time' => 'Operate Time',
            'class_name' => 'Class Name',
            'function_name' => 'Function Name',
            'action' => 'Action',
            'redundancy_id' => 'Redundancy ID',
            'file_path' => 'File Path',
            'old_content' => 'Old Content',
            'new_content' => 'New Content',
            'ip' => 'Ip',
        ];
    }

    public function returnTypeList(){
        return  [
            'MATERIAL_PURCHASE'=>'修改原料采购合同',
            'CONTRACT_SALES'=>'修改销售合同',
            'CONTRACT_AGENT'=>'修改代加工合同',
            'CONTRACT_ENTRUST'=>'修改委外合同',
            'CONTRACT_PROFIT'=>'修改利润合算',
            'TURNOVER_PUBLIC'=>'修改公账流水',
            'TURNOVER_DRAFT'=>'修改汇票流水',
            'TURNOVER_EXPENSE'=>'修改报支流水',
            'STORAGE_SFL'=>'修改收发料流水',
            'STORAGE_PRODUCT'=>'修改产成品入库流水',
            'STORAGE_PRODUCT_TOTAL'=>'修改产成品汇总备注',
            'STORAGE_SFL_TOTAL'=>'修改收发料汇总备注',
            'LH_PROCESS'=>'编辑炉号流程',
            'LH_STATISTICS'=>'编辑炉号成材率返材率备注',
        ] ;
    }

    /**
     * 根据条件查询充值信息
     * @param  array  $ids
     * @param  $table_name
     * @return array
     */
    public function getLogCompareInfoByIdAll($ids,$table_name){
        $db = new Query();

        // 日志数据库
        $db_log = Yii::$app->db;

        $query = $db->select('*')->from($table_name);
        $query->where(['in', 'id', $ids]);
        $query->orderBy("id DESC");

        return $query->all($db_log);
    }

    /**
     * 格式化操作类型名称信息
     * @param $list
     * @param $action_type_list
     * @return mixed
     */
    public function formatList($list,$action_type_list){

        if(!$list){
            return  [] ;
        }

        foreach($list as $k=>$v){
            $action = isset($action_type_list[$v['action']]) ? $action_type_list[$v['action']]  : $v['action'];
            $list[$k]['action'] = $action ;
        }
        return $list ;
    }
}
